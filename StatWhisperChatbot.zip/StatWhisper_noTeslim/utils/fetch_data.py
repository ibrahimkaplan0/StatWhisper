
import requests
from bs4 import BeautifulSoup
import wikipediaapi
import pandas as pd
import time

wiki = wikipediaapi.Wikipedia('en')

def get_wiki_summary(query, sentences=3):
    # Try English, then Turkish
    page = wiki.page(query)
    if page.exists():
        s = page.summary
        # Limit to approximate number of sentences
        parts = s.split('. ')
        return '. '.join(parts[:sentences]).strip() + ('.' if len(parts)>sentences else '')
    return None

def get_f1_standings(limit=10):
    try:
        url = "https://www.formula1.com/en/results.html/2025/drivers.html"
        r = requests.get(url, timeout=10)
        soup = BeautifulSoup(r.text, 'html.parser')
        table = soup.find('table', class_='resultsarchive-table')
        rows = table.find_all('tr')[1:]
        data = []
        for row in rows[:limit]:
            cols = [c.text.strip() for c in row.find_all('td')]
            # depending on site structure, indexes may vary
            if len(cols) >= 3:
                data.append({"Pos": cols[1], "Driver": cols[2], "Points": cols[-1]})
        return pd.DataFrame(data)
    except Exception as e:
        return pd.DataFrame([{"Error": "Could not fetch F1 standings: " + str(e)}])

def get_superlig_standings():
    # Sofascore API sometimes blocks; this is a best-effort example
    try:
        url = "https://api.sofascore.com/api/v1/unique-tournament/36/season/58308/standings/total"
        r = requests.get(url, timeout=10)
        j = r.json()
        data = j.get('standings', [])[0].get('rows', [])
        teams = []
        for t in data:
            teams.append({"Rank": t.get('position'), "Team": t.get('team', {}).get('name'), "Points": t.get('points')})
        return pd.DataFrame(teams)
    except Exception as e:
        return pd.DataFrame([{"Error": "Could not fetch Super Lig standings: " + str(e)}])

def get_bitcoin_price():
    try:
        url = "https://api.coindesk.com/v1/bpi/currentprice/BTC.json"
        r = requests.get(url, timeout=10).json()
        price = r.get('bpi', {}).get('USD', {}).get('rate')
        return {"BTC_USD": price}
    except Exception as e:
        return {"Error": str(e)}

def search_generic(query):
    # Attempt multiple sources: Wikipedia summary first
    res = get_wiki_summary(query, sentences=4)
    if res:
        return {"source": "wikipedia", "text": res}
    # fallback: simple duckduckgo-html result via html scraping (lightweight)
    try:
        url = f"https://html.duckduckgo.com/html?q={requests.utils.quote(query)}"
        r = requests.get(url, timeout=8)
        soup = BeautifulSoup(r.text, 'html.parser')
        results = soup.find_all('a', {'class':'result__a'}, limit=1)
        if results:
            title = results[0].get_text()
            link = results[0].get('href')
            snippet = results[0].parent.find('a').get_text()
            return {"source": "duckduckgo", "title": title, "link": link, "snippet": snippet}
    except Exception:
        pass
    return {"source": "none", "text": "No quick result found."}
