
import streamlit as st
from utils.fetch_data import (
    get_f1_standings, get_superlig_standings,
    get_wiki_summary, get_bitcoin_price, search_generic
)
import pandas as pd
from tabulate import tabulate

st.set_page_config(page_title="StatWhisper", layout="centered")

st.title("📊 StatWhisper")
st.caption("Ask any statistical question — sports, economy, tech, countries, crypto...")

query = st.text_input("Soru (örn. 'F1 sıralaması', 'Türkiye nüfusu', 'Bitcoin fiyatı')")

col1, col2 = st.columns([3,1])
with col2:
    if st.button("Örnek: F1"):
        query = "F1 standings"
    if st.button("Örnek: Süper Lig"):
        query = "Süper Lig standings"
    if st.button("Örnek: Bitcoin"):
        query = "Bitcoin price"

if query:
    st.markdown("**Aranıyor:** " + query)
    q = query.lower()
    try:
        if "f1" in q or "formula" in q:
            df = get_f1_standings()
            if not df.empty:
                st.write(df)
            else:
                st.info("F1 verisi bulunamadı.")
        elif "süper" in q or "super lig" in q or "süper lig" in q:
            df = get_superlig_standings()
            if not df.empty:
                st.write(df)
            else:
                st.info("Süper Lig verisi bulunamadı.")
        elif "bitcoin" in q or "btc" in q:
            p = get_bitcoin_price()
            st.write(p)
        else:
            # generic search
            res = search_generic(query)
            if res.get("source") == "wikipedia":
                st.subheader("Wikipedia özeti")
                st.write(res.get("text"))
            elif res.get("source") == "duckduckgo":
                st.write("**Başlık:**", res.get("title"))
                st.write("**Link:**", res.get("link"))
                st.write("**Özet:**", res.get("snippet"))
            else:
                st.info("Hızlı sonuç bulunamadı. Daha spesifik bir soru deneyin.")
    except Exception as e:
        st.error("Veri çekilirken hata oluştu: " + str(e))

st.markdown('---')
st.caption("GitHub: add your repo link here. README.md içinde teslim bilgilerini eklemeyi unutmayın.")
