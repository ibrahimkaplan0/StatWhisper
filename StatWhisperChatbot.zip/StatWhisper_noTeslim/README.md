
# StatWhisper

**StatWhisper** — Kullanıcının doğal dilde sorduğu istatistiksel sorulara web'den güncel veriler getirerek cevap veren Streamlit tabanlı bir chatbot uygulamasıdır.

## Özellikler
- Genel istatistik sorguları (Wikipedia kullanarak özet bilgi)
- F1 sıralamaları, Süper Lig puan durumu gibi örnek çekiciler
- Basit ve temiz Streamlit arayüzü
- GitHub'a direkt yüklenmeye hazır

## Dosya yapısı
```
StatWhisper/
│
├── statwhisper.py          # Streamlit uygulaması (ana)
├── requirements.txt
├── README.md
└── utils/
    └── fetch_data.py       # Veri çekme yardımcıları
```

## Kurulum & Çalıştırma
1. Klonlayın veya ZIP'i indirin:
```bash
git clone https://github.com/<kullanici-adin>/StatWhisper.git
cd StatWhisper
```

2. Sanal ortam oluşturup bağımlılıkları yükleyin:
```bash
python -m venv venv
source venv/bin/activate   # macOS/Linux
venv\Scripts\activate    # Windows
pip install -r requirements.txt
```

3. Uygulamayı başlatın:
```bash
streamlit run statwhisper.py
```
